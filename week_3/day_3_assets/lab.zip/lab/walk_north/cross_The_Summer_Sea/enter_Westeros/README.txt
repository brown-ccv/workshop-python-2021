Let's ride!

https://gfycat.com/definitivetamearmyworm
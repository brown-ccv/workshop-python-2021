About half way there to The Wall!

https://media.giphy.com/media/110hpIgPYUtsIg/giphy.gif
Such beauty!

https://gfycat.com/acrobatichealthyatlanticbluetang
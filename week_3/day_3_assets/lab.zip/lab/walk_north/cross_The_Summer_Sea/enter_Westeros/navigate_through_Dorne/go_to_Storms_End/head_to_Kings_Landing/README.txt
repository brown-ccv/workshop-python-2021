Capital of the Seven Kingdoms!

https://media.giphy.com/media/kJ3KXdQzBr69y/giphy.gif
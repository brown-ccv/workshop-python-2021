To Castle Black!

https://media.giphy.com/media/3o7qDSozG0KG6RmtBS/giphy.gif
As you stand at the top of The Wall, you see White Walkers in the distance and think to yourself "Mmmm on second thought, maybe I want to go back to the BBQ".

https://media.giphy.com/media/xUPGckDh1hMm4ShSdG/giphy.gif

Before you head back, you must solve an excercise.

Write a Python program to split a list every Nth element.

For example:

    n = 2
    lst = [1, 2, 3, 4, 5, 6]

Expected output:

    [[1, 2,], [3, 4], [5, 6]]
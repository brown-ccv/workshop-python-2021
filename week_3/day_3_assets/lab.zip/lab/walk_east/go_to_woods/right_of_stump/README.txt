Dead end! You must solve an excercise before advancing.

Get the key of a minimum value from the following dictionary:

    sampleDict = {'num_buns': 82, 'num_napkins': 65, 'num_forks': 75}
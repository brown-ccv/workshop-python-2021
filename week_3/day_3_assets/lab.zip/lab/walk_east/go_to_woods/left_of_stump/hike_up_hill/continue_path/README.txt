Dead end! But before you go, you must solve an excercise.

Given two integer numbers return their product. If the product is greater than 1000, then return their sum.

For example:

    number1 = 20
    number2 = 30

Expected output:

    The result is 600
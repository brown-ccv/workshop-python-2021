Before you can make a choice, you must solve an excercise!

Write a Python program to split a given dictionary of lists into list of dictionaries.

Original dictionary of lists:

    orig_dict = {'Chicken_Rating': [88, 89, 62, 95], 'Cornbread_Rating': [77, 78, 84, 80]}
    
Split said dictionary of lists into list of dictionaries:

    [{'Chicken_Rating': 88, 'Cornbread_Rating': 77}, {'Chicken_Rating': 89, 'Cornbread_Rating': 78}, {'Chicken_Rating': 62, 'Cornbread_Rating': 84}, {'Chicken_Rating': 95, 'Cornbread_Rating': 80}]
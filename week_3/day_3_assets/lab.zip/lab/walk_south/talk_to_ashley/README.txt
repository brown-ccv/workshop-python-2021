Ashley says to

    "Not bother with the bathrooms"
    
You may continue.
Nothing here except waves of fowl smells!

You may continue.
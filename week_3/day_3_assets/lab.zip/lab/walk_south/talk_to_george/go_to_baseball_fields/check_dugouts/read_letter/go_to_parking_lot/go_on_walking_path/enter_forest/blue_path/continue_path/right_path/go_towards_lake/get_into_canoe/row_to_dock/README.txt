You see a note on the dock:

    "AVOID THE FROG KING"

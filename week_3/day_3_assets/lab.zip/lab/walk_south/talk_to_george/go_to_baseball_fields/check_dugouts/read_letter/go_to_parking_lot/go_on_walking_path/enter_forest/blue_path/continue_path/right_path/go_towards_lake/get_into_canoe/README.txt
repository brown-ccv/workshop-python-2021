If you have a DICE_PASS, you may skip this for one turn.

Use the `roll_dice()` method with 3 sides to navigate to the next directory:

    1. row_to_dock
    2. row_to_lily_pads
    3. row_to_middle_of_lake
    
If you land back here, you can navigate to any directory without rolling.
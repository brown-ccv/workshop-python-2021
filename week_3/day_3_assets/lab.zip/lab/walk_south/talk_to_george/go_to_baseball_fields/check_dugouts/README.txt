Before you read this letter, solve the following exercise.

Given two strings, s1 and s2, create a new string by appending s2 in the middle of s1

For example:

    s1 = "Ault"
    s2 = "Kelly"
    
Expected output:

    AuKellylt
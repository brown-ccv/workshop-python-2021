The vender says:

    "If you see a kid on your travels, be sure to spark up a chat"

The kid has a message for you:

    "RED RUM. RED RUM. AVOID THE RED RUM IN THE FOREST."
    
That is all. You may advance.
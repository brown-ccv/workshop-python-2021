There's a message on the cave:

    "RIGHT IS RIGHT"
    
That is all. You may advance.
Dead end! Solve the following exercise before advancing.

Write a Python program to print alphabet pattern 'A'.

 ***
*   *
*   *
*****
*   *
*   *
*   *


The Frog King demands you solve an excercise.

Write a Python program to extract numbers from a given string.

For example:

    string = 'frog 12 ribit 45 ribit'
    
Expected output:

    [12, 45]
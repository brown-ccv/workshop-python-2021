The Frog King demands you solve an exercise.

Write a Python program to extract numbers from a given string.

For example:

    string = 'frog 12 rib-it 45 rib-it'
    
Expected output:

    [12, 45]
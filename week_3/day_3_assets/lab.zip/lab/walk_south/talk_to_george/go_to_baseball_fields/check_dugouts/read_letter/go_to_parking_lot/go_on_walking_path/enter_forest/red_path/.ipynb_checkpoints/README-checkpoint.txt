SHOULDA PICKED BLUE!

Solve the following excercise to advance.

Write a Python program to print alphabet pattern 'G'.

  ***                                                                   
 *   *                                                                 
 *                                                                      
 * ***                                                                  
 *   *                                                                  
 *   *                                                                  
  *** 
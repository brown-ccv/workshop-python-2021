There doesn't seem to be any signs of coins here but before you go, you must solve an excercise.

Write a Python function that accepts a string and calculate the number of upper case letters and lower case letters.

For example:

    string = 'The quick Brown Fox'
 
Expected output:
    
    Original String : The quick Brown Fox
    No. of Upper case characters :  3                                                                             
    No. of Lower case Characters :  13
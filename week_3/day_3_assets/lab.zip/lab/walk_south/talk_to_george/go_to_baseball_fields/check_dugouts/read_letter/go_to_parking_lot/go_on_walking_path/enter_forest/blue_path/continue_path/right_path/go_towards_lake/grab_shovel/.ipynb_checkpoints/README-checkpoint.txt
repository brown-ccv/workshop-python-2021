Before you start digging, you must solve an excercise.

Write a Python program to find the difference between two list including duplicate elements.

HINT: use collections module

For example:

    list1 = [1,1,2,3,3,4,4,5,6,7]
    list2 = [1,1,2,4,5,6]
    
Expected output:

    [3, 3, 4, 7]
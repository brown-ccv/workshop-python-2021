SHOULD'VE PICKED BLUE!

Solve the following exercise to advance.

Write a Python program to print alphabet pattern 'G'.

  ***                                                                   
 *   *                                                                 
 *                                                                      
 * ***                                                                  
 *   *                                                                  
 *   *                                                                  
  *** 
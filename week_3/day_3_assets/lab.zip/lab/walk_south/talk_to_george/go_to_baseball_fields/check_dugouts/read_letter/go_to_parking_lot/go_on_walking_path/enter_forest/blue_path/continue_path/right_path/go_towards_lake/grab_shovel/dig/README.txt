If you dig and solve the below exercise, you'll receive a DICE_PASS that lets you skip rolling dice for one turn. Note, you are not required to solve this and you may continue to move if you choose not to solve it.

Write a Python program to check the validity of a password with the following validation requirement:

- At least 1 letter between [a-z] and 1 letter between [A-Z].
- At least 1 number between [0-9].
- At least 1 character from [$#@].
- Minimum length 6 characters.
- Maximum length 16 characters.

HINT: use re module

For example:

    password1 = '$ivdXS7f83L@'
    password2 = 'abcd'
    
Expected output:

    output1 = 'Valid Password'
    output2 = 'Invalid Password'
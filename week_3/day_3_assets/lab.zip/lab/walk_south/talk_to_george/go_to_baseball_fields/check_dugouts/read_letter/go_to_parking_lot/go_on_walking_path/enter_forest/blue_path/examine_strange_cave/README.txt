There's a message on the cave:

    "RIGHT IS RIGHT"

You see some writing on the bench that says:

    "AVOID BEING A GLUTEN AND LOUNGING"
    
You may continue.
Shoulda had the mac and cheese. Tisk tisk.

You must solve an excercise before advancing.

Print downward Half-Pyramid Pattern with Star (asterisk)

Expected output:

* * * * *  
* * * *  
* * *  
* *  
*
Welcome to the Magical Hats game at the soccer field! We've hidden a coin underneath a hat...but which hat?

You may now make sequential hat choices. There is only one coin here so once you've found it, you don't need to look under the other hats.

Enjoy!
Wrong hat! You must solve an exercise before advancing.

Write a Python program to find the second largest number in a list.

For example:

    lst = [1,2,3,4,4]

Expected output:

    3
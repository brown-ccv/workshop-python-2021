YOU'VE BEEN TO THE FOOD BOOTH TWICE YOU GLUTEN!!

For your punishment, you must solve an exercise before advancing.

Write a Python program to find all the values in a list are greater than a specified number.

For example:

    list1 = [220, 330, 500]
    num = 200
    
Expected output:

    [330, 500]
Wrong hat! Before advancing, you must solve an excercise.

Write a Python function that takes two lists and returns True if they have at least one common member; otherwise, returns False.

For example:

    list1 = [1,2,3,4,5]
    list2 = [5,6,7,8,9]
    
Expected output:
    
    True
WHAT ARE YOU DOING?!?! THERE'S NO TIME FOR LOUNGING, WE ARE ON A SCAVENGER HUNT!

For your punishment, you must solve an exercise.

Write a Python program to remove key values pairs from a list of dictionaries.

For example:

    original_list = [{'key1':'value1', 'key2':'value2'}, {'key1':'value3', 'key2':'value4'}]
    
Expected output:
    
    remove_keys = ['key1']
    new_list = [{'key2':'value2'}, {'key2':'value4'}]
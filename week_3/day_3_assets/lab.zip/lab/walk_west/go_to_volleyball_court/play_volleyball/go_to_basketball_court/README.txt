YOU DON'T HAVE ENOUGH ENERGY TO PLAY BASKETBALL!!

You must solve an exercise before advancing.

Merge following two Python dictionaries into one

    dict1 = {'Ten': 10, 'Twenty': 20, 'Thirty': 30}
    dict2 = {'Thirty': 30, 'Forty': 40, 'Fifty': 50}

Expected output:

    {'Ten': 10, 'Twenty': 20, 'Thirty': 30, 'Forty': 40, 'Fifty': 50}
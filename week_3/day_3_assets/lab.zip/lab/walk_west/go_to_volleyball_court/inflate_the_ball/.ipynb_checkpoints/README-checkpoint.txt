As you inflate the ball, you find a note in the ball that reads:

    "BE CAUTIOUS WHEN PLAYING TOO MANY GAMES ON AN EMPTY STOMACH"
    
That is all. You may advance. 
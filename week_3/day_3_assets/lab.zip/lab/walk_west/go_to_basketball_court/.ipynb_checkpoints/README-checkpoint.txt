No one is at the court :( Maybe check later?

You must solve an excercise before advancing.

Write a Python function to reverse a string if it's length is a multiple of 4.

For example:
    
    string1 = 'abcd'
    string2 = 'python'
    
Expected output:

    output1 = 'dcba'
    output2 = 'python'